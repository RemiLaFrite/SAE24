from django.db import models

class Capteur(models.Model):
    id_capteur = models.CharField(primary_key=True, max_length=100)
    endroit = models.CharField(max_length=40, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'capteur'


class Description(models.Model):
    id_capteur = models.ForeignKey(Capteur, models.DO_NOTHING, db_column='id_capteur', blank=True, null=True)
    endroit = models.CharField(max_length=40, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    time = models.TimeField(blank=True, null=True)
    temp = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'description'
